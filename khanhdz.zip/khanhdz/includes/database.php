<?php
$server_name = "localhost";
$db_username = "id14155983_quanghuy1";
$db_password = "Anhkhanh2k1@";
$db_name = "id14155983_quanghuy";

$conn = mysqli_connect($server_name,$db_username,$db_password);
$secutiry = mysqli_select_db($conn,$db_name);
mysqli_query($conn,"set names 'utf8'");  date_default_timezone_set("Asia/Ho_Chi_Minh");


?>