<footer class="main-footer d-flex p-2 px-3 bg-white border-top">
            <ul class="nav">
                <script>
<!--
document.write(unescape("%3Cbr%3E%0A%3Chr%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cdiv%20class%3D%22text-center%22%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3Cb%20class%3D%22small%22%3E%3Cstrong%3E%43%6F%70%79%72%69%67%68%74%A9%44%65%73%69%67%6E%65%72%20%20%3Ca%20href%3D%22https%3A//%7A%61%6C%6F%2E%6D%65%2F%30%38%31%38%31%35%38%35%38%34%22%3E%4E%67%F4%20%44%75%79%20%4B%68%E1%6E%68%3C/a%3E%3C/strong%3E%20%41%6C%6C%20%72%69%67%68%74%73%0D%0A%72%65%73%65%72%76%65%64.%3C/b%3E%0A%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%3C/div%3E"));
//-->
</script>
            </ul>
          
          </footer>
        </main>
      </div>
    </div>
    <div class="promo-popup animated">
      <a href="//zalo.me/08181858584" class="pp-cta extra-action">
        <img src="https://img.icons8.com/bubbles/2x/admin-settings-male.png"> </a>
      <div class="pp-intro-bar"> Liên Hệ Admin
        <span class="close">
          <i class="material-icons">close</i>
        </span>
        <span class="up">
          <i class="material-icons">keyboard_arrow_up</i>
        </span>
      </div>
      <div class="pp-inner-content">
        <h2>Ngô Duy Khánh</h2>
        <p>Chào bạn! bạn cần hỗ trợ gì liên hệ ngay Admin hoặc phía bên phải .</p>
        <a class="pp-cta extra-action" href="//zalo.me/08181858584">Liên Hệ Hỗ Trợ</a>
      </div>
    </div>
   